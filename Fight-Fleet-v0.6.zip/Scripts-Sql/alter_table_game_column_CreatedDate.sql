use FightFleet
GO

alter table Game alter column CreatedDate datetime not null