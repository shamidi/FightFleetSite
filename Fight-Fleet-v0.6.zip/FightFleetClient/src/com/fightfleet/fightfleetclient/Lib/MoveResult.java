package com.fightfleet.fightfleetclient.Lib;

public enum MoveResult {
	Hit,
	Miss
}
