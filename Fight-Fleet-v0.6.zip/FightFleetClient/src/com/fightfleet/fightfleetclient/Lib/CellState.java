package com.fightfleet.fightfleetclient.Lib;

public enum CellState {
	Empty,
	Ship,
	DamagedShip,
	Miss
}
