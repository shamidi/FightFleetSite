﻿namespace FightFleet
{
    public enum GameStatus
    {
        Pending = 1,
        InProgress = 2,
        Finished = 3
    }
}
