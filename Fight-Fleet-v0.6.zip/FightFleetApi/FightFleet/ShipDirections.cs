﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FightFleet
{
    public enum ShipDirections
    {
        Up = 1,
        Right = 2,
        Down = 3,
        Left = 4
    }
}